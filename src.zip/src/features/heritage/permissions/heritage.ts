// This file can be used for defining permission checks related to heritage features.
