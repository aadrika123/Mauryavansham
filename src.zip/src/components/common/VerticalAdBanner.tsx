import { Sparkles, Star } from "lucide-react";
import React from "react";

export const VerticalAdBanner = () => {
  return (
    <div className="container mx-auto px-8 py-2 w-5/6">
      <div className="relative">
        {/* Book-style Ad Banner */}
        <div className="bg-gradient-to-r from-amber-100 via-yellow-50 to-amber-100 border-4 border-amber-300 rounded-2xl shadow-2xl overflow-hidden transform hover:scale-105 transition-transform duration-300">
          <div className="relative p-8 ">
            {/* Decorative Elements */}

            {/* Book Pages Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-20"></div>

            {/* Content */}
            <div className="text-center relative z-10">
              <div className=" relative border-2 border-dashed border-amber-400 rounded-lg p-8 bg-gradient-to-br from-amber-50 to-yellow-100">
                <h3 className="text-xl md:text-3xl font-bold text-amber-800 mb-4">
                  Book Your Ad
                </h3>

                <div className="space-y-4">
                  <div className="absolute top-4 left-4">
                    <Sparkles className="h-8 w-8 text-amber-500 animate-pulse" />
                  </div>
                  <div className="absolute top-4 right-4">
                    <Star className="h-8 w-8 text-amber-500 animate-pulse" />
                  </div>
                  <button className="bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white font-bold py-3 px-8 rounded-full shadow-lg transform hover:scale-105 transition-all duration-200">
                    Place Your Ad Here
                  </button>

                  <p className="text-sm text-amber-600 mt-2">
                    Contact us to feature your message in this premium space
                  </p>
                </div>
              </div>
            </div>

            {/* Decorative Border Pattern */}
            <div className="absolute inset-x-0 top-0 h-2 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-400"></div>
            <div className="absolute inset-x-0 bottom-0 h-2 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-400"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
