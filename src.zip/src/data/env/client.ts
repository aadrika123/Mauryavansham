// This file will contain client-side environment variables.
// Example: export const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;
