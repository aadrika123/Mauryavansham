// This file can be used for data fetching utilities, constants, or mock data.
// Example: export const API_BASE_URL = "/api";
