import RegistrationForm  from "@/src/features/registration/components/RegistrationForm";

export default async function RegistrationPage() {
  return (
    <div className=" mx-auto ">
      <RegistrationForm />
    </div>
  );
}