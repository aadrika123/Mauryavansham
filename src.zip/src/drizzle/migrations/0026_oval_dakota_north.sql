ALTER TABLE "profiles" ADD COLUMN "deactivate_reason" varchar(500);--> statement-breakpoint
ALTER TABLE "profiles" ADD COLUMN "deactivate_review" text;