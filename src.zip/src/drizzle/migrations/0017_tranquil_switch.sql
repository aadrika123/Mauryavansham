ALTER TABLE "achievements" ADD COLUMN "updated_by" varchar(150);--> statement-breakpoint
ALTER TABLE "achievements" ADD COLUMN "updated_by_id" varchar(100);