ALTER TABLE "coaching_centers" ALTER COLUMN "status" SET DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE "ads" ADD COLUMN "ad_url" text;