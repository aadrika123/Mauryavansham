ALTER TABLE "discussions" ADD COLUMN "approved_by_id" varchar(50);--> statement-breakpoint
ALTER TABLE "discussions" ADD COLUMN "rejected_by_id" varchar(50);