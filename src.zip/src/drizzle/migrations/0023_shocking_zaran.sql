ALTER TABLE "profiles" ADD COLUMN "brothers_details" json;--> statement-breakpoint
ALTER TABLE "profiles" ADD COLUMN "sisters_details" json;