ALTER TABLE "profiles" ALTER COLUMN "brothers_details" SET DEFAULT '[]';--> statement-breakpoint
ALTER TABLE "profiles" ALTER COLUMN "sisters_details" SET DEFAULT '[]';