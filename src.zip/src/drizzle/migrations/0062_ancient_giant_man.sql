ALTER TABLE "events" ADD COLUMN "reason" text;--> statement-breakpoint
ALTER TABLE "events" ADD COLUMN "rejected_by" varchar(255);