ALTER TABLE "users" DROP COLUMN "caste";--> statement-breakpoint
ALTER TABLE "users" DROP COLUMN "diet";--> statement-breakpoint
ALTER TABLE "users" DROP COLUMN "smoking";--> statement-breakpoint
ALTER TABLE "users" DROP COLUMN "drinking";--> statement-breakpoint
ALTER TABLE "users" DROP COLUMN "hobbies";