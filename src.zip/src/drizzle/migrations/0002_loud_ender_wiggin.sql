ALTER TABLE "coaching_centers" ADD COLUMN "logo_url" text;--> statement-breakpoint
ALTER TABLE "coaching_centers" DROP COLUMN "image_url";