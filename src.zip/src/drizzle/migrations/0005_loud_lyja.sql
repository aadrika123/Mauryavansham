ALTER TABLE "ads" ADD COLUMN "rejected_by" text;--> statement-breakpoint
ALTER TABLE "ads" ADD COLUMN "approved_by" text;