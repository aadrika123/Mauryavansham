ALTER TABLE "users" DROP COLUMN "father_name";--> statement-breakpoint
ALTER TABLE "users" DROP COLUMN "mother_name";--> statement-breakpoint
ALTER TABLE "users" DROP COLUMN "siblings_count";--> statement-breakpoint
ALTER TABLE "users" DROP COLUMN "family_status";--> statement-breakpoint
ALTER TABLE "users" DROP COLUMN "native_place";