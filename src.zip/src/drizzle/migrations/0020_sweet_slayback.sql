ALTER TABLE "heritage" ADD COLUMN "created_by_id" varchar(50);--> statement-breakpoint
ALTER TABLE "heritage" ADD COLUMN "created_by_name" varchar(100);--> statement-breakpoint
ALTER TABLE "heritage" ADD COLUMN "updated_by_id" varchar(50);--> statement-breakpoint
ALTER TABLE "heritage" ADD COLUMN "updated_by_name" varchar(100);