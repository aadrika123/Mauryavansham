import {
  pgTable,
  serial,
  integer,
  varchar,
  text,
  boolean,
  timestamp,
  json,
} from "drizzle-orm/pg-core";

export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id", { length: 256 }).notNull(), // Removed .unique() constraint
  name: varchar("name", { length: 100 }),
  profileRelation: varchar("profile_relation", { length: 100 }),
  customRelation: varchar("custom_relation", { length: 100 }),
  nickName: varchar("nick_name", { length: 100 }),
  phoneNo: varchar("phone_no", { length: 15 }),
  gender: varchar("gender", { length: 10 }),
  email: varchar("email", { length: 100 }),
  website: varchar("website", { length: 100 }),
  dob: varchar("dob", { length: 10 }), // Assuming date format is YYYY-MM-DD
  height: varchar("height", { length: 10 }),
  weight: varchar("weight", { length: 10 }),
  complexion: varchar("complexion", { length: 50 }),
  bodyType: varchar("body_type", { length: 50 }),
  maritalStatus: varchar("marital_status", { length: 50 }),
  languagesKnown: varchar("languages_known", { length: 100 }),
  hobbies: varchar("hobbies", { length: 100 }),
  aboutMe: text("about_me"),
  highestEducation: varchar("highest_education", { length: 100 }),
  collegeUniversity: varchar("college_university", { length: 100 }),
  occupation: varchar("occupation", { length: 100 }),
  companyOrganization: varchar("company_organization", { length: 100 }),
  designation: varchar("designation", { length: 100 }),
  workLocation: varchar("work_location", { length: 100 }),
  annualIncome: varchar("annual_income", { length: 100 }),
  workExperience: varchar("work_experience", { length: 100 }),
  fatherName: varchar("father_name", { length: 100 }),
  fatherOccupation: varchar("father_occupation", { length: 100 }),
  motherName: varchar("mother_name", { length: 100 }),
  motherOccupation: varchar("mother_occupation", { length: 100 }),
  brothers: varchar("brothers", { length: 100 }),
  sisters: varchar("sisters", { length: 100 }),

  // NEW: Store sibling details as JSON arrays
  brothersDetails: json("brothers_details").default("[]"),
  sistersDetails: json("sisters_details").default("[]"),

  familyIncome: varchar("family_income", { length: 100 }),
  gotraDetails: varchar("gotra_details", { length: 100 }),
  ancestralVillage: varchar("ancestral_village", { length: 100 }),
  familyHistory: text("family_history"),
  communityContributions: text("community_contributions"),
  familyTraditions: text("family_traditions"),
  diet: varchar("diet", { length: 100 }),
  smoking: varchar("smoking", { length: 100 }),
  drinking: varchar("drinking", { length: 100 }),
  exercise: varchar("exercise", { length: 100 }),
  religiousBeliefs: varchar("religious_beliefs", { length: 100 }),
  musicPreferences: varchar("music_preferences", { length: 100 }),
  moviePreferences: varchar("movie_preferences", { length: 100 }),
  readingInterests: varchar("reading_interests", { length: 100 }),
  travelInterests: varchar("travel_interests", { length: 100 }),
  castPreferences: varchar("cast_preferences", { length: 100 }),
  facebook: varchar("facebook", { length: 100 }).default(""),
  instagram: varchar("instagram", { length: 100 }).default(""),
  linkedin: varchar("linkedin", { length: 100 }).default(""),
  profileImage: varchar("profile_picture", { length: 255 }).default(""),
  profileImage1: varchar("profile_image1", { length: 255 }).default(""),
  profileImage2: varchar("profile_image2", { length: 255 }).default(""),
  profileImage3: varchar("profile_image3", { length: 255 }).default(""),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  isPremium: boolean("is_premium").default(false),
  isVerified: boolean("is_verified").default(false),
  isActive: boolean("is_active").default(true),
  isDeleted: boolean("is_deleted").default(false),
  deactivateReason: varchar("deactivate_reason", { length: 500 }),
  deactivateReview: text("deactivate_review"),
});

// Type definitions for better type safety
export type SiblingDetails = {
  occupation: string;
  maritalStatus: string;
  spouseName?: string;
  spouseOccupation?: string;
  name?: string;
};

export type ProfileInsert = typeof profiles.$inferInsert;
export type ProfileSelect = typeof profiles.$inferSelect;

// If you want to ensure unique combinations, you could add a composite unique constraint
// For example, to ensure unique email per user:
// .unique(["userId", "email"])

// export const updateProfileSchema = profiles.partial();
